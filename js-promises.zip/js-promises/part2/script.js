const baseURL = "https://deckofcardsapi.com/api/deck";

// Part 1: Draw a single card from a new deck and log its value and suit
/**********************************/
axios.get(`${baseURL}/new/draw/?count=1`)
    .then(response => {
        console.log("Card1 Value: " + response.data.cards[0].value);
        console.log("Card1 Suit: " + response.data.cards[0].suit);
    })
    .catch(err => {
        console.error(err);
    });

// Part 2: Draw a single card from a new deck, then draw another from the same deck
/**********************************/
axios.get(`${baseURL}/new/draw/?count=1`)
    .then(response => {
        // Save the deck ID to use for subsequent draws
        deckId = response.data.deck_id;
        console.log("Card2 Value: " + response.data.cards[0].value);
        console.log("Card2 Suit: " + response.data.cards[0].suit);

        // Draw a second card from the same deck
        return axios.get(`${baseURL}/${deckId}/draw/?count=1`);
    })
    .then(response => {
        // Log the second card's value and suit
        console.log("Card3 Value: " + response.data.cards[0].value);
        console.log("Card3 Suit: " + response.data.cards[0].suit);
    })
    .catch(err => {
        console.error(err);
    });

// Part 3: Draw cards on click until there are no cards left in the deck
/**********************************/
let newDeckId; // Holds the deck ID for subsequent draws
let zIndexCounter = 0; // Used to control layering of card images

$(document).ready(function () {
    $drawBtn = $('#draw');

    // Shuffle a new deck and get its ID
    axios.get(`${baseURL}/new/shuffle`)
        .then(response => {
            newDeckId = response.data.deck_id;

            // Event listener for "Draw" button to fetch and display a new card on each click
            $drawBtn.on('click', function () {
                axios.get(`${baseURL}/${newDeckId}/draw/?count=1`)
                    .then(response => {
                        const remaining = response.data.remaining;

                        // Hide button if no cards remain in the deck
                        if (remaining === 0) {
                            $drawBtn.hide();
                            return;
                        }

                        let cardImage = response.data.cards[0].image; // Get the image URL of the drawn card
                        let $cardImg = $(`<img src="${cardImage}" class="card">`); // Create a new image element for the card

                        // Generate random rotation and position offsets for a scattered effect
                        let randomRotation = Math.floor(Math.random() * 90) - 45; // Between -45 and 45 degrees
                        let randomX = Math.floor(Math.random() * 60) - 30; // Horizontal offset between -30px and +30px
                        let randomY = Math.floor(Math.random() * 60) - 30; // Vertical offset between -30px and +30px

                        // Apply CSS styles for position, rotation, and layering
                        $cardImg.css({
                            "z-index": zIndexCounter,
                            "transform": `rotate(${randomRotation}deg)`,
                            "top": `${randomY}px`,
                            "left": `${randomX}px`
                        });

                        zIndexCounter++; // Increase z-index for next card to layer it on top

                        // Prepend the new card to the #cards container and fade it in
                        $('#cards').prepend($cardImg);
                        $cardImg.fadeIn(500);
                    })
                    .catch(err => {
                        console.error(err);
                    });
            });
        })
        .catch(err => {
            console.error(err);
        });
});
