// Part 1: Single Fact for a Favorite Number
const favoriteNumber = 8; 
const favNumFactUrl = `http://numbersapi.com/${favoriteNumber}?json`;

axios.get(favNumFactUrl)
    .then(response => {
        $("#single-fact").html(`<strong>Single Fact:</strong> ${response.data.text}`);
    })
    .catch(error => console.error('Error fetching single fact:', error));

// Part 2: Facts for Multiple Numbers
const numbers = [3, 6, 9, 12];
const multipleFactsUrl = `http://numbersapi.com/${numbers}?json`;

axios.get(multipleFactsUrl)
    .then(response => {
        const facts = Object.values(response.data).map(fact => `<p>${fact}</p>`).join("");
        $("#multiple-facts").html(`<h2>Multiple Facts</h2>${facts}`);
    })
    .catch(error => console.error('Error fetching multiple facts:', error));

// Part 3: Multiple Facts forf Favorite Number
const factPromises = Array(4).fill().map(() => axios.get(favNumFactUrl));

Promise.all(factPromises)
    .then(responses => {
        const factsText = responses.map(response => `<p>${response.data.text}</p>`).join("");
        $("#favorite-number-facts").html(`<h2>Four Facts about ${favoriteNumber}</h2>${factsText}`);
    })
    .catch(error => console.error('Error fetching facts for favorite number:', error));















// const nums = []

// for (let i = 0; i < 4; i++) {
//     nums.push(`http://numbersapi.com/random/year`)
// }

// nums.forEach(num => {
//     axios.get(num)
//         .then(response => {
//             $(".random").append(`<li>${response.data}</li>`)
//         })
//         .catch(error => {
//             console.error(error);
//         });

// })

// axios.get('http://numbersapi.com/23/math')
//   .then(res1 => {
//     $(".favorite").append(`<li>${res1.data}</li>`)
//     return axios.get('http://numbersapi.com/23/trivia')
//   })
//   .then(res2 => {
//     $(".favorite").append(`<li>${res2.data}</li>`)
//     return axios.get('http://numbersapi.com/23/date')
//   })
//   .then(res3 => {
//     $(".favorite").append(`<li>${res3.data}</li>`)
//     return axios.get('http://numbersapi.com/23/year')
//   })
//   .then(res4 => {
//     $(".favorite").append(`<li>${res4.data}</li>`)
//   })
//   .catch(error => {
//     console.error(error);
//   });
