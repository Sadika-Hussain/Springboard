// Part 1: Single Fact for a Favorite Number
const favoriteNumber = 8; 
const favNumFactUrl = `http://numbersapi.com/${favoriteNumber}?json`;

axios.get(favNumFactUrl)
    .then(response => {
        $("#single-fact").html(`<strong>Single Fact:</strong> ${response.data.text}`);
    })
    .catch(error => console.error('Error fetching single fact:', error));

// Part 2: Facts for Multiple Numbers
const numbers = [3, 6, 9, 12];
const multipleFactsUrl = `http://numbersapi.com/${numbers}?json`;

axios.get(multipleFactsUrl)
    .then(response => {
        const facts = Object.values(response.data).map(fact => `<p>${fact}</p>`).join("");
        $("#multiple-facts").html(`<h2>Multiple Facts</h2>${facts}`);
    })
    .catch(error => console.error('Error fetching multiple facts:', error));

// Part 3: Multiple Facts forf Favorite Number
const factPromises = Array(4).fill().map(() => axios.get(favNumFactUrl));

Promise.all(factPromises)
    .then(responses => {
        const factsText = responses.map(response => `<p>${response.data.text}</p>`).join("");
        $("#favorite-number-facts").html(`<h2>Four Facts about ${favoriteNumber}</h2>${factsText}`);
    })
    .catch(error => console.error('Error fetching facts for favorite number:', error));













